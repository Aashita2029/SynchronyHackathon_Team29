import os
from autogen.agentchat import AssistantAgent, UserProxyAgent
from autogen.ext.tools import FunctionTool
from app.agents.CalendarAgent_service import get_calendar_events

# Build the tool
get_events_tool = FunctionTool(
    func=get_calendar_events,
    name="get_calendar_events",
    description="Get sprint events (upcoming 7 days) from user’s primary Google Calendar",
    strict=True
)

# Initialize model client (replace with Gemini endpoint if needed)
# NOTE: You must implement or import OpenAIChatCompletionClient or Gemini equivalent
client = OpenAIChatCompletionClient(
    model="gemini-2.5-flash",  # or ""
    api_key=os.getenv("GEMINI_API_KEY"),
    parallel_tool_calls=False
)

# Define assistant with your calendar tool
assistant = AssistantAgent(
    name="CalendarAssistant",
    model_client=client,
    tools=[get_events_tool],
    system_message="""
You are a personal calendar assistant. 
When users ask for events, call get_calendar_events(max_time).
Return human-friendly summaries of the events.
""",
    reflect_on_tool_use=True
)

# Define user proxy to execute tool calls
user_proxy = UserProxyAgent(
    name="user", code_execution_config=False
)

# Entry point to run queries
def query_calendar(prompt: str) -> str:
    user_proxy.initiate_chat(assistant, message=prompt)
    # access assistant.latest_message or conversation history
    return assistant.latest_message.content 