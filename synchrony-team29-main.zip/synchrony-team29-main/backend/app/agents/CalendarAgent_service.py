from datetime import datetime, timedelta
from typing import List, Dict, Optional

from googleapiclient.discovery import build
from autogen.core.tools import FunctionTool
from app.utils.settings import credentials, CALENDAR_ID

# Build the Calendar service
calendar_service = build("calendar", "v3", credentials=credentials)

def get_calendar_events(max_time: Optional[str] = None) -> List[Dict]:
    """
    Fetch sprint-related events occurring between now and max_time (default: next 7 days).
    Returns a simplified JSON list with title, start, end.
    """
    now = datetime.utcnow().isoformat() + "Z"
    until = max_time or (datetime.utcnow() + timedelta(days=7)).isoformat() + "Z"

    events = calendar_service.events().list(
        calendarId=CALENDAR_ID,
        timeMin=now,
        timeMax=until,
        maxResults=10,
        singleEvents=True,
        orderBy='startTime'
    ).execute().get('items', [])

    return [
        {
            "title": e.get("summary", "No Title"),
            "start": e["start"].get("dateTime", e["start"].get("date")),
            "end": e["end"].get("dateTime", e["end"].get("date"))
        } for e in events
    ]

# Wrap it as a FunctionTool for AutoGen
get_events_tool = FunctionTool(
    func=get_calendar_events,
    name="get_calendar_events",
    description="Get upcoming sprint events from the user's calendar",
    strict=True
) 