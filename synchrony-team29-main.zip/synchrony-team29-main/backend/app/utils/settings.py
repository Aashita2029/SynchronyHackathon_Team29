import os
from google.oauth2 import service_account

# Load credentials from the JSON file
CREDENTIALS_PATH = os.getenv(
    "GOOGLE_CREDENTIALS_JSON",
    os.path.join(os.path.dirname(__file__), "../../../annular-sky-454421-t6-2b600b31325a.json")
)
credentials = service_account.Credentials.from_service_account_file(CREDENTIALS_PATH)

# Calendar ID from environment or hardcoded
CALENDAR_ID = os.getenv(
    "CALENDAR_ID",
    "calendar@annular-sky-454421-t6.iam.gserviceaccount.com"
) 