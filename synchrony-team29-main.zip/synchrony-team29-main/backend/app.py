
# app.py
from datetime import datetime, timedelta
from google.oauth2 import service_account
from googleapiclient.discovery import build

# ← For programmatic ADC:
from google.cloud import aiplatform
from langchain_google_vertexai import VertexAI
from langchain.agents import initialize_agent, Tool

# ——— CONFIG ——————————————————————————————————
SERVICE_ACCOUNT_FILE = r""
CALENDAR_ID          = ""
GEMINI_API_KEY       = ""
PROJECT_ID           = ""
REGION               = ""
# ————————————————————————————————————————

# 1) Load your SA key and init Vertex AI client
credentials = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE
)
aiplatform.init(
    project=PROJECT_ID,
    location=REGION,
    credentials=credentials
)

# 2) Build the Google Calendar client (can reuse the same creds)
calendar = build(
    "calendar", "v3",
    credentials=credentials.with_scopes(["https://www.googleapis.com/auth/calendar"])
)

# 3) Define your two tools
def list_sprint_events(_: str) -> str:
    now = datetime.utcnow().isoformat() + "Z"
    items = (
        calendar.events()
        .list(
            calendarId=CALENDAR_ID,
            timeMin=now,
            maxResults=10,
            singleEvents=True,
            orderBy="startTime"
        )
        .execute()
        .get("items", [])
    )
    if not items:
        return "No upcoming sprint events."
    return "\n".join(
        f"- {e['summary']} @ {e['start'].get('dateTime', e['start'].get('date'))}"
        for e in items
    )

def add_sprint_event(text: str) -> str:
    try:
        title, when = text.replace("Add ", "", 1).split(" on ", 1)
        dt = datetime.strptime(when, "%B %d at %I%p")
        dt = dt.replace(year=datetime.utcnow().year)
        start = dt.isoformat()
        end   = (dt + timedelta(hours=1)).isoformat()
        calendar.events().insert(
            calendarId=CALENDAR_ID,
            body={
                "summary": title.strip(),
                "start":   {"dateTime": start},
                "end":     {"dateTime": end}
            }
        ).execute()
        return f"✅ Created '{title.strip()}' at {start}"
    except Exception as e:
        return f"⚠️ Failed to add event: {e}"

# 4) Spin up the LangChain agent
llm = VertexAI(
    model_name="gemini-2.5-flash",
    temperature=0,
)

tools = [
    Tool("List Sprint Events", list_sprint_events, "List the next 10 sprint events."),
    Tool("Add Sprint Event",   add_sprint_event,   "Add <title> on <Month> <Day> at <HHa/pm>"),
]

agent = initialize_agent(
    tools=tools,
    llm=llm,
    agent="zero-shot-react-description",
    verbose=True
)

# 5) Simple CLI
if __name__ == "__main__":
    print("🏃‍♀️ Sprint-Calendar Agent ready. Commands: list sprint events | add sprint event … | exit")
    while True:
        q = input(">> ").strip()
        if q.lower() in ("exit", "quit"):
            break
        print(agent.run(q))
